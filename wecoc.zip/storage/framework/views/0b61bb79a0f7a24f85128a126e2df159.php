<div class="bg-slate-50">
    <div class=" pt-20 pb-40 lg:px-20 px-5" id="at-glance">
        <div class="flex-col flex gap-3 mb-10">
            <h4 class="text-2xl text-primary-600 font-semibold">Scientific Program</h4>
            <h1 class="text-4xl text-primary-700 font-semibold">Program at Glance</h1>
        </div>

        <div class="container mx-auto items-center">
            
        </div>
    </div>
    <div class="bg-local pt-28 pb-52 lg:px-20 px-5 bg-doctor bg-primary-50" id="schedule">
        <div class="flex-col flex gap-3 mb-16">
            <h4 class="text-2xl text-primary-600 font-semibold">Scientific Program</h4>
            <h1 class="text-4xl text-primary-700 font-semibold">Scientific Schedule</h1>
        </div>

        <div>
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('resources.schedule', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-408101851-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

        </div>
    </div>
</div>
<?php /**PATH /home/wecocid/wecoc/resources/views/livewire/pages/scientific-program.blade.php ENDPATH**/ ?>