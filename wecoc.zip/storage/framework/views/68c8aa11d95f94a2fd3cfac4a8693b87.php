<div>
    <div class="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-8">
        <?php $__currentLoopData = $faculties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faculty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card glass">
            <figure class="">
                <?php if($faculty->getMedia('images')->isEmpty()): ?>
                <div class="avatar p-3">
                    <div class="rounded-full ring ring-primary  ring-offset-base-100 ring-offset-4">
                        <img src="<?php echo e(asset('images/doctor.png')); ?>" alt="Default Doctor Image" class="rounded-lg" />
                    </div>
                </div>
                <?php else: ?>
                <?php $__currentLoopData = $faculty->getMedia('images'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="avatar p-3">
                    <div class="rounded-full ring ring-primary  ring-offset-base-100 ring-offset-4">
                        <img src="<?php echo e($image->getUrl()); ?>" alt="<?php echo e($faculty->name); ?>" />
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </figure>
            <div class="card-body">
                <h2 class="card-title text-primary-800 hover:cursor-pointer">
                    <?php echo e($faculty->name); ?>

                </h2>
                <p class=""><?php echo e($faculty->country); ?></p>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
</div><?php /**PATH D:\Project\template-website-event\resources\views/livewire/resources/faculty.blade.php ENDPATH**/ ?>