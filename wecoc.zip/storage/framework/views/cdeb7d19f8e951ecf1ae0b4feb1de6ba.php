<!DOCTYPE html>
<html class="scroll-smooth" data-theme="emerald" lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8" />

    <meta name="application-name" content="<?php echo e(config('app.name')); ?>" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <title><?php echo e($title ?? config('app.name')); ?></title>
    <!-- favicon -->
    <link rel="shortcut icon" href="images/logo/favicon.ico">

    <style>
        [x-cloak] {
            display: none !important;
        }
    </style>

    <link href="https://cdn.jsdelivr.net/npm/daisyui@4.11.1/dist/full.min.css" rel="stylesheet" type="text/css" />
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://kit.fontawesome.com/6d07745da9.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="css/custom.css" />

    <?php echo \Filament\Support\Facades\FilamentAsset::renderStyles() ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
</head>

<body class="antialiased">

    <?php if (isset($component)) { $__componentOriginal70541bdd6cf5b73640c65c5445d19f7f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal70541bdd6cf5b73640c65c5445d19f7f = $attributes; } ?>
<?php $component = App\View\Components\Nav\Menu::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('nav.menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Nav\Menu::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal70541bdd6cf5b73640c65c5445d19f7f)): ?>
<?php $attributes = $__attributesOriginal70541bdd6cf5b73640c65c5445d19f7f; ?>
<?php unset($__attributesOriginal70541bdd6cf5b73640c65c5445d19f7f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal70541bdd6cf5b73640c65c5445d19f7f)): ?>
<?php $component = $__componentOriginal70541bdd6cf5b73640c65c5445d19f7f; ?>
<?php unset($__componentOriginal70541bdd6cf5b73640c65c5445d19f7f); ?>
<?php endif; ?>

    <?php echo e($slot); ?>


    <?php if (isset($component)) { $__componentOriginala634b8466405ac7ef4d0ed5aebeaedfb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala634b8466405ac7ef4d0ed5aebeaedfb = $attributes; } ?>
<?php $component = App\View\Components\Nav\Footer::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('nav.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Nav\Footer::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala634b8466405ac7ef4d0ed5aebeaedfb)): ?>
<?php $attributes = $__attributesOriginala634b8466405ac7ef4d0ed5aebeaedfb; ?>
<?php unset($__attributesOriginala634b8466405ac7ef4d0ed5aebeaedfb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala634b8466405ac7ef4d0ed5aebeaedfb)): ?>
<?php $component = $__componentOriginala634b8466405ac7ef4d0ed5aebeaedfb; ?>
<?php unset($__componentOriginala634b8466405ac7ef4d0ed5aebeaedfb); ?>
<?php endif; ?>
    <a href="#" onclick="topFunction()" id="back-to-top" class="btn btn-square btn-sm btn-primary z-40 fixed right-5 md:right-10 bottom-10 over:-translate-y-1 hover:scale-105"><i class="fa-solid text-white pt-2 fa-arrow-up"></i></a>

    <script src="js/custom.js"></script>
    <?php echo \Filament\Support\Facades\FilamentAsset::renderScripts() ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>
</body>

</html><?php /**PATH /home/wecocid/wecoc/resources/views/components/layouts/app.blade.php ENDPATH**/ ?>