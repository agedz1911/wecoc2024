<div>

    <div class="flex items-center justify-center">
        <div x-data="{ openTab: 1 }" class="lg:w-3/4 w-full mx-auto">
            <div class="">
                <div class="mb-4 flex space-x-4 p-2 bg-white rounded-lg shadow-md">
                    <button x-on:click="openTab = 1" :class="{ 'bg-primary-600 text-white': openTab === 1 }"
                        class="flex-1 py-2 px-4 rounded-md focus:outline-none focus:shadow-outline-blue transition-all duration-300">26
                        October</button>
                    <button x-on:click="openTab = 2" :class="{ 'bg-primary-600 text-white': openTab === 2 }"
                        class="flex-1 py-2 px-4 rounded-md focus:outline-none focus:shadow-outline-blue transition-all duration-300">27
                        October</button>
                    <button x-on:click="openTab = 3" :class="{ 'bg-primary-600 text-white': openTab === 3 }"
                        class="flex-1 py-2 px-4 rounded-md focus:outline-none focus:shadow-outline-blue transition-all duration-300">28
                        October</button>
                </div>

                <div x-show="openTab === 1"
                    class="transition-all duration-300 bg-white p-4 rounded-lg shadow-md border-x-4 border-primary">
                    <?php $__currentLoopData = $sesis->where('date', '2024-10-26'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sesi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="overflow-x-auto">
                        <table class="table">
                            <thead>
                                <tr class="text-base font-semibold mb-2 text-primary-800 ">
                                    <th class="w-1/12"><?php echo e(\Carbon\Carbon::parse($sesi->timeStart)->format('H.i')); ?> - <?php echo e(\Carbon\Carbon::parse($sesi->timeEnd)->format('H.i')); ?></th>
                                    <th colspan="3"><?php echo e($sesi->session); ?> <br> Room: <?php echo e($sesi->room); ?> <br>
                                        Moderator: <?php echo e($sesi->moderator->name); ?> (<?php echo e($sesi->moderator->country); ?>)
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr class="bg-base-200">
                                    <th>Time</th>
                                    <td>Topic</td>
                                    <td>Speaker</td>
                                    <td>Country</td>
                                </tr>
                                <?php $__currentLoopData = $sesi->schedule; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th><?php echo e(\Carbon\Carbon::parse($schedule->timeStart)->format('H.i')); ?> -
                                        <?php echo e(\Carbon\Carbon::parse($schedule->timeEnd)->format('H.i')); ?></th>
                                    <td><?php echo e($schedule->topic); ?></td>
                                    <td><?php echo e($schedule->faculty->name); ?></td>
                                    <td><?php echo e($schedule->faculty->country); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>

                <div x-show="openTab === 2"
                    class="transition-all duration-300 bg-white p-4 rounded-lg shadow-md border-x-4 border-primary">
                    <?php $__currentLoopData = $sesis->where('date', '2024-10-27'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sesi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="overflow-x-auto">
                        <table class="table">
                            <thead>
                                <tr class="text-base font-semibold mb-2 text-primary-800">
                                    <th class="w-1/12"><?php echo e(\Carbon\Carbon::parse($sesi->timeStart)->format('H.i')); ?> - <?php echo e(\Carbon\Carbon::parse($sesi->timeEnd)->format('H.i')); ?></th>
                                    <th colspan="3"><?php echo e($sesi->session); ?> <br> Room: <?php echo e($sesi->room); ?> <br>
                                        Moderator: <?php echo e($sesi->moderator->name); ?> (<?php echo e($sesi->moderator->country); ?>)
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr class="bg-base-200">
                                    <th>Time</th>
                                    <td>Topic</td>
                                    <td>Speaker</td>
                                    <td>Country</td>
                                </tr>
                                <?php $__currentLoopData = $sesi->schedule; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th><?php echo e(\Carbon\Carbon::parse($schedule->timeStart)->format('H.i')); ?> -
                                        <?php echo e(\Carbon\Carbon::parse($schedule->timeEnd)->format('H.i')); ?></th>
                                    <td><?php echo e($schedule->topic); ?></td>
                                    <td><?php echo e($schedule->faculty->name); ?></td>
                                    <td><?php echo e($schedule->faculty->country); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <div x-show="openTab === 3"
                    class="transition-all duration-300 bg-white p-4 rounded-lg shadow-md border-x-4 border-primary">
                    <?php $__currentLoopData = $sesis->where('date', '2024-10-28'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sesi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="overflow-x-auto">
                        <table class="table">
                            <thead>
                                <tr class="text-base font-semibold mb-2 text-primary-800">
                                    <th class="w-1/12"><?php echo e(\Carbon\Carbon::parse($sesi->timeStart)->format('H.i')); ?> - <?php echo e(\Carbon\Carbon::parse($sesi->timeEnd)->format('H.i')); ?></th>
                                    <th colspan="3"><?php echo e($sesi->session); ?> <br> Room: <?php echo e($sesi->room); ?> <br>
                                        Moderator: <?php echo e($sesi->moderator->name); ?> (<?php echo e($sesi->moderator->country); ?>)
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr class="bg-base-200">
                                    <th>Time</th>
                                    <td>Topic</td>
                                    <td>Speaker</td>
                                    <td>Country</td>
                                </tr>
                                <?php $__currentLoopData = $sesi->schedule; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th><?php echo e(\Carbon\Carbon::parse($schedule->timeStart)->format('H.i')); ?> -
                                        <?php echo e(\Carbon\Carbon::parse($schedule->timeEnd)->format('H.i')); ?></th>
                                    <td><?php echo e($schedule->topic); ?></td>
                                    <td><?php echo e($schedule->faculty->name); ?></td>
                                    <td><?php echo e($schedule->faculty->country); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php /**PATH /home/wecocid/wecoc/resources/views/livewire/resources/schedule.blade.php ENDPATH**/ ?>