<div>
    <div class="flex flex-col items-center">
        <?php $__currentLoopData = $uniqueCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="badge bg-primary-900 text-slate-300 py-5 px-10 text-lg font-semibold my-10"><?php echo e($category); ?></div>
        
        <div class="flex flex-col md:flex-row justify-center items-start flex-wrap gap-4">
            <?php $__currentLoopData = $committees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $committee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($committee->category == $category): ?>
            <div class="">
                <div class="card w-full md:w-72 bg-base-100 shadow-xl">
                    <figure>
                        <?php if($committee->getMedia('committee')->isEmpty()): ?>
                        <div class="avatar w-full md:w-72 px-3">
                            <div class="rounded-full ring ring-primary  ring-offset-base-100 ring-offset-4">
                                <img src="<?php echo e(asset('images/doctor.png')); ?>" alt="Default Doctor Image"
                                    class="rounded-lg" />
                            </div>
                        </div>
                        <?php else: ?>
                        <?php $__currentLoopData = $committee->getMedia('committee'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="avatar w-full md:w-72 px-3">
                            <div class="rounded-lg ring ring-primary ring-offset-base-100 ring-offset-4">
                                <img src="<?php echo e($image->getUrl()); ?>" alt="<?php echo e($committee->name); ?>" />
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </figure>
                    <div class="card-body px-1 items-center text-center">
                        <h2 class="text-xl font-semibold">
                            <?php echo e($committee->name); ?>

                        </h2>
                        <p class="text-lg text-gray-400">
                            <?php echo e($committee->title); ?>

                        </p>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div><?php /**PATH /home/wecocid/wecoc/resources/views/livewire/resources/committee.blade.php ENDPATH**/ ?>