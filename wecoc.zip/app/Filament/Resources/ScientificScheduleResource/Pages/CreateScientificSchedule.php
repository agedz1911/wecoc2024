<?php

namespace App\Filament\Resources\ScientificScheduleResource\Pages;

use App\Filament\Resources\ScientificScheduleResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateScientificSchedule extends CreateRecord
{
    protected static string $resource = ScientificScheduleResource::class;
}
