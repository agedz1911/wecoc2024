<?php

namespace App\Filament\Resources\AtGlanceResource\Pages;

use App\Filament\Resources\AtGlanceResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateAtGlance extends CreateRecord
{
    protected static string $resource = AtGlanceResource::class;
}
